#package-root
this library was created as part of a school project.
